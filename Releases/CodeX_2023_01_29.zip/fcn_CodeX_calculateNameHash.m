%  fcn_CodeX_calculateNameHash
%  This is a helper function for the CodeX library that hashes strings. It
%  it not a problem to be solved, but rather a function that is used often
%  in many of the problems and so is kept as a stand-alone function.
%